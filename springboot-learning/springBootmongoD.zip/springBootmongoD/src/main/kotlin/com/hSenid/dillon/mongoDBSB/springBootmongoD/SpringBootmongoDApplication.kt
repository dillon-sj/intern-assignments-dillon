package com.hSenid.dillon.mongoDBSB.springBootmongoD

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class SpringBootmongoDApplication

fun main(args: Array<String>) {
	runApplication<SpringBootmongoDApplication>(*args)
}
