package com.hSenid.dillon.springLearning.springbootlearning

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class SpringbootLearningApplicationTests {

	@Test
	fun contextLoads() {
	}

}
